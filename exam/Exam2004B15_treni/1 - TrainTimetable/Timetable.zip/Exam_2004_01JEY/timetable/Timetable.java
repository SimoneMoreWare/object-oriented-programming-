package timetable;

import java.util.Collection;
import java.util.List;


public class Timetable {

  public Path createPath(String code, String category) {
    // TODO Auto-generated method stub
    return null;
  }

  public Collection getPaths() {
    // TODO Auto-generated method stub
    return null;
  }

  public Path getPath(String code) {
    // TODO Auto-generated method stub
    return null;
  }

  public Train newTrain(String code, int day, int month, int year) 
  	throws InvalidPath {
    // TODO Auto-generated method stub
    return null;
  }

  public List getTrains() {
    // TODO Auto-generated method stub
    return null;
  }

}

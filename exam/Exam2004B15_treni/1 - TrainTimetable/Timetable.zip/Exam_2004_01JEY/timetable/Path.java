package timetable;

import java.util.List;


public class Path {

  public String getCode() {
    // TODO Auto-generated method stub
    return null;
  }

  public String getCategory() {
    // TODO Auto-generated method stub
    return null;
  }

  public boolean isExtraordinary() {
    // TODO Auto-generated method stub
    return false;
  }

  public void setExtraordinary(boolean b) {
    // TODO Auto-generated method stub
    
  }

  public TrainStop addStop(String stationName, int hour, int minutes) {
    // TODO Auto-generated method stub
    return null;
  }

  public List getTrainStops() {
    // TODO Auto-generated method stub
    return null;
  }

  public int maxDelay() {
    // TODO Auto-generated method stub
    return 0;
  }
  public int minDelay() {
    // TODO Auto-generated method stub
    return 0;
  }
  public int totalDelay() {
    // TODO Auto-generated method stub
    return 0;
  }

}

package timetable;


public class TrainStop {

  public String getStation() {
    // TODO Auto-generated method stub
    return null;
  }

  public int getHour() {
    // TODO Auto-generated method stub
    return 0;
  }

  public int getMinutes() {
    // TODO Auto-generated method stub
    return 0;
  }

}

package timetable;


public class Train {

  public Path getPath() {
    // TODO Auto-generated method stub
    return null;
  }

  public int getDay() {
    // TODO Auto-generated method stub
    return 0;
  }

  public int getMonth() {
    // TODO Auto-generated method stub
    return 0;
  }

  public int getYear() {
    // TODO Auto-generated method stub
    return 0;
  }

  public Passage registerPassage(String string, int i, int j) 
  	throws InvalidStop {
    // TODO Auto-generated method stub
    return null;
  }

  public boolean arrived() {
    // TODO Auto-generated method stub
    return false;
  }

  public int maxDelay() {
    // TODO Auto-generated method stub
    return 0;
  }
  public int minDelay() {
    // TODO Auto-generated method stub
    return 0;
  }
  public int totalDelay() {
    // TODO Auto-generated method stub
    return 0;
  }

}

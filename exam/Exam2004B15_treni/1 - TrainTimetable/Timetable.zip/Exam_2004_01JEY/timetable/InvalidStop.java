package timetable;


public class InvalidStop extends Exception {

}

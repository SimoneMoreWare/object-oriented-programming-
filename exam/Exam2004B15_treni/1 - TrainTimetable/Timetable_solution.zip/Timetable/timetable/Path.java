package timetable;

import java.util.*;

public class Path {
	private List stops = new ArrayList();

	private String code;

	private String category;

	private boolean extraordinary;

	private List trains = new ArrayList();

	public Path(String code, String category) {
		this.code = code;
		this.category = category;
		this.extraordinary = false;
	}

	public String getCode() {
		return code;
	}

	public String getCategory() {
		return category;
	}

	public boolean isExtraordinary() {
		return extraordinary;
	}

	public void setExtraordinary(boolean b) {
		extraordinary = b;
	}

	public TrainStop addStop(String stationName, int hour, int minutes) {
		TrainStop f = new TrainStop(stationName, hour, minutes);
		stops.add(f);
		return f;
	}

	public List getTrainStops() {
		return stops;
	}

	public int maxDelay() {
		int max = 0;
		for (Iterator iter = trains.iterator(); iter.hasNext();) {
			Train element = (Train) iter.next();
			if (element.totalDelay() > max) {
				max = element.totalDelay();
			}
		}
		return max;
	}

	public int minDelay() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int totalDelay() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int averageDelay() {
		int sum = 0;
		for (Iterator iter = trains.iterator(); iter.hasNext();) {
			Train element = (Train) iter.next();
			sum += element.totalDelay();
		}
		return sum / trains.size();
	}

	public void addTrain(Train t) {
		trains.add(t);
	}
	public List getTrains() {
		ArrayList l = new ArrayList(trains);
		Collections.sort(l);
		return l;
	}

}

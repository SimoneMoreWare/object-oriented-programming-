package timetable;

import timetable.TrainStop;

public class Passage {
	private TrainStop stop;
	private int hour;
	private int minutes;

	public Passage(TrainStop stop, int hour, int minutes) {
		this.stop = stop;
		this.hour = hour;
		this.minutes = minutes;
	}

	public String getStation() {
		return stop.getStation();
	}

	public int getHour() {
		return hour;
	}

	public int getMinutes() {
		return minutes;
	}

	public int delay() {
		return 60 * (this.hour - stop.getHour()) + this.minutes
				- stop.getMinutes();
	}

}

package timetable;

import java.util.*;

public class Train implements Comparable {
	private List passages = new ArrayList();
	  private Path path;
	  private int day;
	  private int month;
	  private int year;

	  public Train(Path path, int day, int month, int year) {
	  	this.path = path;
	  	this.day = day;
	  	this.month = month;
	  	this.year = year;
	  }

  public Path getPath() {
        return path;
  }

  public int getDay() {
    
    return day;
  }

  public int getMonth() {
   
    return month;
  }

  public int getYear() {
   
    return year;
  }

  public Passage registerPassage(String code, int hour, int minutes) 
  	throws InvalidStop {
  	TrainStop f = null;
  	for (Iterator iter = path.getTrainStops().iterator(); iter.hasNext();) {
  		TrainStop element = (TrainStop) iter.next();
      if(element.getStation().equals(code)){
      	f = element;
      }
    }
    if(f==null) throw new InvalidStop();
  	Passage p = new Passage(f,hour,minutes);
  	passages.add(p);
    return p;
  }

  public boolean arrived() {
  	Passage lastPass = (Passage)passages.get(passages.size()-1);
  	TrainStop lastFerm = (TrainStop)path.getTrainStops().get(path.getTrainStops().size()-1);
    return lastPass.getStation().equals(lastFerm.getStation());
  }

  public int maxDelay() {
  	int max = 0;
  	for (Iterator iter = passages.iterator(); iter.hasNext();) {
  		Passage element = (Passage) iter.next();
      if(element.delay()>max){
      	max = element.delay();
      }
    }
    return max;
  }
  public int minDelay() {
    // TODO Auto-generated method stub
    return 0;
  }
  public int totalDelay() {
  	return ((Passage)passages.get(passages.size()-1)).delay();
  }
  public int compareTo(Object o) {
  	Train t = (Train) o;
  	//  this is for descendant order
  	int diff = t.year - this.year;
  	if (diff!=0) return diff;
  	diff = t.month-this.month;
  	if (diff!=0) return diff;
  	diff = t.day-this.day;
  	if (diff!=0) return diff;
  	return 0;
  	
  	//this is for ascendant order
  	//int diff = this.year - t.year;
  	//if (diff!=0) return diff;
  	//diff = this.month-t.month;
  	//if (diff!=0) return diff;
  	//diff = this.day-t.day;
  	//if (diff!=0) return diff;
  	//return 0;
  }
}

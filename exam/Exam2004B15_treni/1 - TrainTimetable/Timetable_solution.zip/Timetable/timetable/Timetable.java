package timetable;

import java.util.*;


public class Timetable {
	private Map paths = new HashMap();
	
  public Path createPath(String code, String category) {
  	Path p = new Path(code,category);
    paths.put(code,p);
    return p;
  }

  public Collection getPaths() {
  	return paths.values();
  }

  public Path getPath(String code) {
  	return (Path)paths.get(code);
  }

  public Train newTrain(String code, int day, int month, int year) 
  	throws InvalidPath {
  	Path p = (Path) paths.get(code);
  	if(p==null) throw new InvalidPath();
  	Train t = new Train(p,day,month,year);
    p.addTrain(t);
    return t;
  }

  public List getTrains() {
    ArrayList list = new ArrayList();
    Iterator i = paths.values().iterator();
    while (i.hasNext()) {
    	Path p = (Path) i.next();
    	list.addAll(p.getTrains());
    }
    return list;
  }

}

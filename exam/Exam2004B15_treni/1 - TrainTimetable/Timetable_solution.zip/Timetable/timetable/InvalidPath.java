package timetable;


public class InvalidPath extends Exception {

}

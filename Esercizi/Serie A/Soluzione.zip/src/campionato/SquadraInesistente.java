package campionato;

public class SquadraInesistente extends Exception {

}
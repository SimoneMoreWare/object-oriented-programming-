package campionato;

import java.util.*;

public class Squadra {
	private Map<Integer, Calciatore> giocatori = new TreeMap<Integer, Calciatore>();
	private String nome;

	public void aggiungiCalciatore(String cognome, String nome, String nazione,
			int numeroMaglia) {
		giocatori.put(numeroMaglia, new Calciatore(cognome, nome, nazione,
				numeroMaglia));
	}

	public String getCalciatore(int numero) {
		if (giocatori.containsKey(numero))
			return giocatori.get(numero).getCalciatore();
		return "";
	}

	public Squadra(String nome) {
		this.nome = nome;
	}

	public long getCosto(int maglia) {
		if (!giocatori.containsKey(maglia))
			return 0;
		return giocatori.get(maglia).getCosto();
	}

	public void setCosto(int maglia, long costo) {
		if (!giocatori.containsKey(maglia))
			return;
		giocatori.get(maglia).setCosto(costo);
	}

	public long valoreSquadra() {
		Iterator s = giocatori.keySet().iterator();
		long valore = 0;
		while (s.hasNext()) {
			valore += giocatori.get(s.next()).getCosto();
		}
		return valore;
	}

	public String listaCalciatori() {
		Iterator s = giocatori.keySet().iterator();
		String sq = new String();
		if (giocatori.size() == 0)
			return "";
		while (s.hasNext()) {
			Integer i = (Integer) s.next();
			sq += i + "." + giocatori.get(i).getCalciatore() + "\n";
		}
		return sq;
	}
	public String listaCalciatoriCognome() {
		Collection<Calciatore> c = giocatori.values();
		ArrayList<Calciatore> l = new ArrayList<Calciatore>(c);
		Comparator<Calciatore> comp = new Comparator<Calciatore>() {
			public int compare(Calciatore c1, Calciatore c2) {
				int t = c1.getCognome().compareTo(c2.getCognome());
				if (t!=0) return t;
				return c1.getNome().compareTo(c2.getNome());
			}
		};
		Collections.sort(l, comp);
		
		String sq = "";
		for( Calciatore cc : l) {
					sq += cc.getNumeroMaglia() + "." + cc.getCalciatore() + "\n";
		}
		return sq;
			
	}
}

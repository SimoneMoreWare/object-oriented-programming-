package campionato;

public class Calciatore  {
private String nome;
private String cognome;
private String nazione;
private int numeromaglia;
private long costo = 0;
public String getCalciatore()
{
	return nome + " " + cognome + "("+ nazione + ")"; 
	}
public long getCosto() {
	return costo;
}
public void setCosto(long costo) {
	this.costo = costo;
}
public Calciatore(String nome, String cognome, String nazione, int numeromaglia) {
	this.nome = nome;
	this.cognome = cognome;
	this.nazione = nazione;
	this.numeromaglia = numeromaglia;
}
public String getNome() {
	return nome;
}
public String getCognome() {
	return cognome;
}
public int getNumeroMaglia() {
	return numeromaglia;
}
}

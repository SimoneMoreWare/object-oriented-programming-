package campionato;
import java.io.*;
import java.util.*;
/* MEMO:
 * 
 * 1) DO NOT MODIFY THE NAME OF THIS CLASS (SerieA)
 * 2) DO NOT MODIFY THE NAME OF THIS PACKAGE (campionato) 
 * 3) DO NOT MODIFY THE SIGNATURE OF FOLLOWING METHODS */

public class SerieA {
private Map<String,Squadra> squadre = new TreeMap<String,Squadra>();
	
//R1: Squadre
	public void aggiungiSquadra(String nome) {
// Se la squadra e' gia' stata inserita evito di perderla!		
		if (squadre.containsKey(nome)) return;
		squadre.put(nome,new Squadra(nome)); 
	}
	public String getSquadre() {
		Iterator s = squadre.keySet().iterator();
		String t = new String();
		while (s.hasNext())
		{t += s.next();
		 if (s.hasNext()) {t += ",";}
		}
		return t;}
	
//R2: Calciatori	
	public void aggiungiCalciatore(String squadra, 
		String cognome, String nome, String nazione, int numeroMaglia)
				throws SquadraInesistente {
		if (!squadre.containsKey(squadra)) 
			throw new SquadraInesistente();
		this.squadre.get(squadra).aggiungiCalciatore(cognome, nome, nazione, numeroMaglia);
	}
	
	public String getCalciatore(String squadra, int numero) {
		if (!squadre.containsKey(squadra)) return "";
		return this.squadre.get(squadra).getCalciatore(numero);
	}

	public void setCosto(String squadra, int numeroMaglia, long costo) {
		if (!squadre.containsKey(squadra)) return;
		squadre.get(squadra).setCosto(numeroMaglia, costo);
	}
	public long getCosto(String squadra, int numeroMaglia) {
		if (!squadre.containsKey(squadra)) return 0;
		return squadre.get(squadra).getCosto(numeroMaglia);
	}
	
//	R3: costo	
	public long valoreSquadra(String squadra) {
		if (!squadre.containsKey(squadra)) return 0;
		return squadre.get(squadra).valoreSquadra();
	}
	public String valoreMassimo() {
		long vm = 0;
		long vs;
		Iterator s = squadre.keySet().iterator();
		while (s.hasNext())
		{vs= squadre.get(s.next()).valoreSquadra();	
		 if (vm < vs) vm=vs;
		}
		return vm + " Euro";
	}
	public long valoreTotale() {
		long vt = 0;
		Iterator s = squadre.keySet().iterator();
		while (s.hasNext())
		{vt += squadre.get(s.next()).valoreSquadra();			
		}
		return vt;
	}
	
	
//R4: Lista	
	public String listaCalciatori(String squadra) {
		if (!squadre.containsKey(squadra)) return "";
		return squadre.get(squadra).listaCalciatori();
	}
	
//R5: Salva Lista	calciatori di'squadra' su 'file' di testo
	public String salvaCalciatori(String squadra, String file) {
		String s = squadre.get(squadra).listaCalciatori();
		if (s.equals("")) return null;
		try {			
		PrintStream br = new PrintStream (new FileOutputStream(file));
		br.print(squadre.get(squadra).listaCalciatori());
		br.close();
		} catch (IOException e) {System.out.println(e.getMessage());}		
		return null;
	}

//main di esempio d'uso	
	public static void main(String[] args) {
	
		SerieA campionato = new SerieA();

		campionato.aggiungiSquadra("Milan");
		campionato.aggiungiSquadra("Juventus");
		campionato.aggiungiSquadra("Inter");
		System.out.println(campionato.getSquadre());
		// Visualizza:	"Inter, Juventus, Milan"
		
		campionato.aggiungiSquadra("Roma");
		//aggiungo 4 calciatori
		//l'ultimo caso mi lancia eccezione
		try{
			campionato.aggiungiCalciatore("Roma", "Totti", "Francesco", "Italia", 10);
			campionato.aggiungiCalciatore("Inter", "Crespo", "Hernan", "Argentina", 9);
			campionato.aggiungiCalciatore("Milan", "Gattuso", "Gennaro", "Italia", 8);
			campionato.aggiungiCalciatore("Milan", "Maldini", "Paolo", "Italia", 3);
			campionato.aggiungiCalciatore("Milan", "Pirlo", "Andrea", "Italia", 14);
			campionato.aggiungiCalciatore("Inter", "Vieira", "Patrick", "Francia", 7);
			campionato.aggiungiCalciatore("Torino", "Abbiati", "Gianluca", "Italia", 12);
		} catch (SquadraInesistente e) {
			System.out.println(e.getMessage());
			
		}

		
		//Visualizza "Francesco Totti (Roma)"
		System.out.println(campionato.getCalciatore("Roma", 10));
		
		//Visualizza "3. Paolo Maldini (Italia)" sulla prima linea
		// e poi:    "8. Gennaro Gattuso (Italia)" sulla seconda linea 
		// e poi:    "14. Andrea Pirlo (Italia)" sulla terza linea 
		System.out.println(campionato.listaCalciatori("Milan"));
		campionato.aggiungiSquadra("Lanerossi");
		campionato.setCosto("Roma", 10, 125);
		campionato.setCosto("Inter", 9, 129);
		campionato.setCosto("Inter", 7, 50);
		campionato.setCosto("Milan", 8, 1000);
		campionato.setCosto("Milan", 3, 2000);
		campionato.setCosto("Milan", 14, 3000);
		System.out.println("Valore massimo :" + campionato.valoreMassimo());
		System.out.println("Valore totale :" + campionato.valoreTotale());
		System.out.println("Valore Milan :" + campionato.valoreSquadra("Milan"));
		System.out.println("Valore Roma :" + campionato.valoreSquadra("Roma"));
		System.out.println("Valore Inter :" + campionato.valoreSquadra("Inter"));
		System.out.println("Valore Torino :" + campionato.valoreSquadra("Torino"));
		campionato.aggiungiSquadra("Milan");		
		campionato.salvaCalciatori("Inter", "inter.txt");
		campionato.salvaCalciatori("Milan", "milan.txt");
		campionato.salvaCalciatori("Roma", "roma.txt");
		campionato.salvaCalciatori("Lanerossi", "Lanerossi.txt");
		
	}

}

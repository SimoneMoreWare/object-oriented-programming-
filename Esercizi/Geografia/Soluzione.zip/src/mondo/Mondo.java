package mondo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

public class Mondo {

	public static void main(String[] args) {
		Mondo m = new Mondo();
		m.caricaDati("stati.txt", "confini.txt");
		String s = m.ordinaPerPopolazione();
		System.out.println(s);
	}

	private HashMap<String, Stato> stati = new HashMap<String, Stato>();

	public boolean aggiungiStato(String stato, String capitale,	long popolazione, double dimensione) {

		if (stati.containsKey(stato.toUpperCase()))
			return false;
		Stato s = new Stato(stato, capitale, popolazione, dimensione);
		stati.put(stato.toUpperCase(), s);

		return true;
	}

	public String getCapitale(String stato) {
		if (!stati.containsKey(stato.toUpperCase())) return null;
		 return stati.get(stato.toUpperCase()).getCapitale();
	}

	public long getPopolazione(String stato) {
		if (!stati.containsKey(stato.toUpperCase()))
			return 0;
		return stati.get(stato.toUpperCase()).getPopolazione();
	}

	public double getDimensione(String stato) {
		if (!stati.containsKey(stato.toUpperCase()))
			return 0.0;
		return stati.get(stato.toUpperCase()).getDimensione();
	}

	// return true se dati caricati correttamente , false in caso di errori
	public boolean caricaDati(String stati, String confini) {
		try {
			BufferedReader instati = new BufferedReader(new FileReader(stati));
			String s = ""; 
			while ((s= instati.readLine()) != null) {

				StringTokenizer st = new StringTokenizer(s, ":");
				String stato = st.nextToken().trim();
				String resto = st.nextToken();
				int i=0;
				while ( i < resto.length() ) {
					char c = resto.charAt(i);
					//Character.isDigit(c)
					if (c >= '0' && c <= '9') 
						break;
					i++;	
				}
				if (i==resto.length()) {
					System.out.println("Linea irregolare");
					return false;
				}
				String capitale = resto.substring(0, i).trim();
				String cifre = resto.substring(i);
				StringTokenizer number = new StringTokenizer(cifre);
				String dim = number.nextToken().replace(",", "").trim();
				String pop = number.nextToken().replace(",", "").trim();
				
				long popolazione = Long.parseLong(pop);
				double dimensione = Double.parseDouble(dim);
				if (!aggiungiStato(stato, capitale, popolazione,dimensione))
					return false;
			}
			BufferedReader inconfini = new BufferedReader(new FileReader(confini));
			String s2 = "";
			while ((s2= inconfini.readLine()) != null) {
				StringTokenizer token2 = new StringTokenizer(s2, ":");
				String stato1 = token2.nextToken().trim();
				String stato2 = token2.nextToken().trim();
				setConfine(stato1, stato2);
			}

		} catch (Exception e) {
			System.out.println("Errore");
			return false;
		}
		return true;
	}

	public void setConfine(String stato1, String stato2) {
		Stato s1 = stati.get(stato1.toUpperCase().trim());
		Stato s2 = stati.get(stato2.toUpperCase().trim());
		if (s1 != null && s2 != null) {
			s1.setConfinante(s2);
			s2.setConfinante(s1);
		} 
	}

	public int numeroConfinanti(String stato) {
		Stato s = stati.get(stato.toUpperCase());
		return (s != null) ? s.numeroConfinanti() : 0;
	}

	public boolean confinano(String stato1, String stato2) {

		Stato s1 = stati.get(stato1.toUpperCase());
		Stato s2 = stati.get(stato2.toUpperCase());

		return (s1 != null && s2 != null)? s1.confina(stato2) : false;
	}

	public String getConfinanti(String stato) {
		Stato s = stati.get(stato.toUpperCase());
		return (s != null) ? s.getConfini() : "";
	}

	@SuppressWarnings("unchecked")
	public String ordinaPerPopolazione() {
		List<Stato> ordina = new ArrayList<Stato>(stati.values());
		Collections.sort(ordina);
		String s = "";
		for (int i = 0; i < ordina.size(); i++) {
			Stato temp = ordina.get(i);
			s = s + (i + 1) + ". " + temp.getNome() + " "
					+ Long.toString(temp.getPopolazione()) + "\n";
		}

		return s;
	}

	public String ordinaPerDimensione() {
		List<Stato> ordina = new ArrayList<Stato>(stati.values());
		Collections.sort(ordina, 
		  new Comparator<Stato>() {
			public int compare(Stato o1, Stato o2) {
				return (int) Math.round(10.0*(o2.getDimensione() - o1.getDimensione()));
			}
		});
		String s = "";
		for (int i = 0; i < ordina.size(); i++) {
			Stato temp = ordina.get(i);
			s = s + (i + 1) + ". " + temp.getNome() + " "
					+ Double.toString(temp.getDimensione()) + "\n";
		}
		return s;
	}
}

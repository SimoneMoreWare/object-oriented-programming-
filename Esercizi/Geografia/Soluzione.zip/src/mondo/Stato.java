package mondo;

import java.util.ArrayList;

public class Stato implements Comparable {

	private String nome;
	private String capitale;
	private long popolazione;
	private double dimensione;
	private ArrayList<Stato> confini = new ArrayList<Stato>();
	
	public Stato(String stato, String capitale, long popolazione, double dimensione) {
		this.nome = stato;
		this.capitale = capitale;
		this.popolazione = popolazione;
		this.dimensione = dimensione;
	}

	public String getCapitale() {
		return capitale;
	}

	public long getPopolazione() {
		return popolazione;
	}

	public double getDimensione() {
		return dimensione;
	}

	public int compareTo(Object arg0) {
		Stato s = (Stato) arg0;
		return (int) (s.getPopolazione() - this.getPopolazione());
	}

	public String getNome() {
		return nome;
	}

	public void setConfinante(Stato s) {
		confini.add(s);
	}

	public int numeroConfinanti() {
		return confini.size();
	}

	public boolean confina(String stato) {
		for (int i = 0; i < confini.size(); i++) {
			if (confini.get(i).getNome().trim().equalsIgnoreCase(stato.trim()))
				return true;
			}
		return false;
	}

	public String getConfini() {
		String s = "";
		for (int i = 0; i < confini.size(); i++) {
			s += confini.get(i).getNome();
			if (i!=confini.size()-1)
				s += ", ";
		}
		return s;
	}

}

import java.lang.reflect.*;
import java.util.List;
import java.util.StringTokenizer;

import mondo.*;
import junit.framework.TestCase;



public class TestR2 extends TestCase {
	Mondo m;
  public TestR2(String arg0) {
    super(arg0);
    m = new Mondo();
    m.caricaDati("stati.txt","confini.txt");
  }

 

  public void testCapitale()  {
	  String s = "Brunei :	Bandar Seri Begawan 	2,228 	379,444";
	  assertTrue(m.getCapitale("Brunei").indexOf("Bandar Seri Begawan") !=-1);
	  assertTrue(m.getCapitale("Mongolia").indexOf("Ulan Bator") !=-1);
  }
  public void testDimensione()  {
	  assertEquals(2228, m.getDimensione("Brunei") , 0.001);
	  assertEquals(1068296, m.getDimensione("Argentina") , 0.001);
  }
  public void testPopolazione()  {
	  assertEquals(39921833, m.getPopolazione("Argentina"));
	  assertEquals(379444, m.getPopolazione("Brunei"));
  }
  
  public void testVaticano()  {
	  assertEquals(932, m.getPopolazione("Vatican City"));
	  assertEquals(0.17, m.getDimensione("Vatican City"),0.01);
  }
  //Verifico se � stata usata una HashMap o HashTable non public
  public void testStruttura() {
	  Field[] f = m.getClass().getDeclaredFields();
	  Field[] f2 = m.getClass().getFields();
	  boolean flag = false;
	  for (int i=0; i< f.length; i++) {
		  Class<?> cl = f[i].getType();
		  System.out.println(cl.getName());
		  if (cl.getName().indexOf("HashMap")!=-1
				||  cl.getName().indexOf("TreeMap")!=-1
				||  cl.getName().indexOf("Map")!=-1) {
		  	flag = true;
		  	int m = f[i].getModifiers();
		  	assertFalse(Modifier.isPublic(m));
		  }
	  }
	  assertTrue(flag);
  }
 }

import mondo.*;
import junit.framework.TestCase;

public class TestR1 extends TestCase {

  public TestR1(String arg0) {
    super(arg0);
    
  }

  public void testAggiungiStato() {
	  Mondo m=new Mondo();
		m.aggiungiStato("Italia", "Roma", 58000000, 116000.0);
		assertEquals("Roma",m.getCapitale("Italia"));
		assertEquals(58000000,m.getPopolazione("Italia"));
		assertEquals(116000,m.getDimensione("Italia"),0.01);
 }
  public void testAggiungiStato2() {
	  Mondo m=new Mondo();
		m.aggiungiStato("Italia", "Roma", 58000000, 116000.0);
		m.aggiungiStato("Italia", "pippo", 3, 10.0);
		assertEquals("Roma",m.getCapitale("Italia"));
		
 }
 
  public void testCaricaFile() {
	  Mondo m=new Mondo();
	  assertTrue(m.caricaDati("stati.txt","confini.txt"));
  }
  public void testVuoto() {
	  Mondo m=new Mondo();
	  assertEquals("", m.ordinaPerDimensione());
	  assertEquals("", m.ordinaPerPopolazione());
  }
}

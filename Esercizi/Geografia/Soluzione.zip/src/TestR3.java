import java.util.StringTokenizer;

import mondo.*;
import junit.framework.TestCase;

public class TestR3 extends TestCase {
	Mondo m;
  public TestR3(String arg0) {
    super(arg0);
    m = new Mondo();
    m.caricaDati("stati.txt","confini.txt");
  }
  public void testConfinano() {
	  Mondo m=new Mondo();
		m.aggiungiStato("Italia", "Roma", 58000000, 116000.0);
		m.aggiungiStato("Francia", "Parigi", 60000000, 200000.0);
		m.setConfine("Italia", "Francia");
		assertTrue(m.confinano("Francia","Italia"));
		
  }
  public void testGetConfinanti()  {
	  String s = m.getConfinanti("Italy");
	  
	  assertTrue(s.indexOf("Switzerland")!=-1);
	  assertTrue(s.indexOf("France")!=-1);
	  assertTrue(s.indexOf("Austria")!=-1);
	  assertTrue(s.indexOf("Slovenia")!=-1);
	  
  }

  public void testConfini2()  {
	  String s = m.getConfinanti("Italy");
	  StringTokenizer st = new StringTokenizer(s,",");
	  assertEquals(4, st.countTokens());
	  st.nextToken();
	 
	  assertFalse(m.getConfinanti("Italy").endsWith(","));
  }
  
  public void testNumeroConfinanti()  {
	  assertEquals(4, m.numeroConfinanti("Italy"));
	  assertEquals(8, m.numeroConfinanti("Germany"));
	  assertEquals(0, m.numeroConfinanti("Iceland"));
  }
 }

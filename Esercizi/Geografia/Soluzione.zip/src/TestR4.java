import mondo.*;
import junit.framework.TestCase;

public class TestR4 extends TestCase {
	Mondo m;
	  public TestR4(String arg0) {
	    super(arg0);
	    m = new Mondo();
	    m.caricaDati("stati.txt","confini.txt");
	  }

  public void testOrdineDim()  {
	 String s = m.ordinaPerDimensione();
	 assertTrue(s.startsWith("1. Russia 6592735"));
	 assertTrue(s.startsWith("1. Russia 6592735.0\n"));
	 String ss = "195. Vatican City 0.17";
	 assertTrue(s.endsWith(ss) || s.endsWith(ss+"\n"));
  }
  
  public void testOrdineDim2() {
		 String s = m.ordinaPerDimensione();
		 assertTrue(s.indexOf("Italy") < s.indexOf("Tuvalu"));
		 assertTrue(s.indexOf("India") < s.indexOf("Germany"));
		 assertTrue(s.indexOf("Marshall Islands") < s.indexOf("San Marino"));
  }
  public void testOrdineDim3() {
		 String s = m.ordinaPerDimensione();
		 assertTrue(s.indexOf("142. Equatorial Guinea 10830")!=-1);
		 assertTrue(s.indexOf("159. Marshall Islands 4577") != -1);
}
  public void testOrdinePop() {
	  String s =  m.ordinaPerPopolazione();
	
	  assertTrue(s.startsWith("1. China 1313973713"));
	  
	  assertTrue(s.startsWith("1. China 1313973713\n"));
	  String ss = "195. Vatican City 932";
	  assertTrue(s.endsWith(ss) || s.endsWith(ss+"\n"));
  }
	  public void testOrdinePop2()  {
		  String s =  m.ordinaPerPopolazione();
		  assertTrue(s.indexOf("Italy") !=-1);
		  assertTrue(s.indexOf("Tuvalu") !=-1);
		  assertTrue(s.indexOf("Bangladesh") !=-1);
		  assertTrue(s.indexOf("Australia") !=-1);
		  assertTrue(s.indexOf("Congo (Zaire)") !=-1);
		  assertTrue(s.indexOf("Korea, North") !=-1);
		  
		  assertTrue(s.indexOf("Italy") < s.indexOf("Tuvalu"));
		  assertTrue(s.indexOf("Bangladesh") < s.indexOf("Australia"));
		  assertTrue(s.indexOf("Congo (Zaire)") < s.indexOf("Korea, North"));
		  
	  }
	  public void testOrdinePop3() {
			 String s = m.ordinaPerPopolazione();
			 assertTrue(s.indexOf("10. Japan 127463611")!=-1);
			 assertTrue(s.indexOf("22. United Kingdom 60609153") != -1);
			 assertTrue(s.indexOf("23. Italy 58133509") != -1);
	}
		
}

package TestJ;
import supermercato.*;

import junit.framework.TestCase;

public class TestR4_Promozione extends TestCase {

  public TestR4_Promozione(String arg0) {
    super(arg0);
  }

  private Cassa setupCassa() {
    Cassa cassa = new Cassa();
    cassa.aggiungiProdotto("P001", "Acciughe", 3.0);
    cassa.aggiungiProdotto("P002", "Aglio", 1.5);
    return cassa;
  }

  public void testPezzoPromozione() {
    Cassa cassa = setupCassa();
    cassa.promozione("P001", 50);
    Pezzo pezzo = cassa.leggi("P001");

    assertEquals(1.5, pezzo.getPrezzo(), 0.001);
    double totale = cassa.totale();

    assertEquals(1.5, totale, 0.001);
  }

  public void testPromozioneMetaSessione() {
    Cassa cassa = setupCassa();
    Pezzo pezzo1 = cassa.leggi("P001");
    cassa.promozione("P001", 50);
    Pezzo pezzo2 = cassa.leggi("P001");
    cassa.promozione("X", 0);
    Pezzo pezzo3 = cassa.leggi("P001");

    double totale = cassa.totale();

    assertEquals(3.0, pezzo1.getPrezzo(), 0.001);
    assertEquals(1.5, pezzo2.getPrezzo(), 0.001);
    assertEquals(3.0, pezzo3.getPrezzo(), 0.001);

    assertEquals(7.5, totale, 0.001);
  }

  public void testPromozioneDieciPerc() {
    Cassa cassa = setupCassa();
    Pezzo pezzo1 = cassa.leggi("P001");
    cassa.promozione("P001", 10);
    Pezzo pezzo2 = cassa.leggi("P001");

    double prezzo2 = pezzo1.getPrezzo() * 0.9;
    // dieci percento di sconto

    assertEquals(prezzo2, pezzo2.getPrezzo(), 0.001);
  }

}

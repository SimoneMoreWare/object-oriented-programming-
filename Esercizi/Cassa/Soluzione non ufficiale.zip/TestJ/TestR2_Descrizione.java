package TestJ;
import supermercato.*;
import junit.framework.TestCase;

public class TestR2_Descrizione extends TestCase {

	public TestR2_Descrizione(String arg0) {
		super(arg0);
	}

	private Cassa setupCassa(){
	Cassa cassa = new Cassa();
	cassa.aggiungiProdotto("P001","Acciughe",3.0);
	cassa.aggiungiProdotto("P002","Aglio",1.5);
	return cassa;
	}

    public void testUnProdotto(){
    	Cassa cassa = setupCassa();
    	
    	Pezzo pezzo = cassa.leggi("P001");
    	
    	String codice = "P001";
		String nome = "Acciughe";
		double prezzo = 3.0;
    	
    	assertEquals(nome,pezzo.getNome());
    	assertEquals(prezzo,pezzo.getPrezzo(),0.001);
    	assertEquals(prezzo,cassa.totale(),0.001);
    }

	public void testSessione(){
		Cassa cassa = setupCassa();
		Pezzo pezzo;
		pezzo = cassa.leggi("P001");
		assertEquals("Acciughe",pezzo.getNome());
		pezzo = cassa.leggi("P002");
		assertEquals("Aglio",pezzo.getNome());
		pezzo = cassa.leggi("P001");
		assertEquals("Acciughe",pezzo.getNome());
		double totale = cassa.totale();
		totale = cassa.totale();
		assertEquals(7.5,totale,0.001);
		cassa.close();
	}

	public void testCodiceNonValido(){
		Cassa cassa = setupCassa();
    	
		Pezzo pezzo = cassa.leggi("P00X");
		assertSame(null,pezzo);    	
	}

}

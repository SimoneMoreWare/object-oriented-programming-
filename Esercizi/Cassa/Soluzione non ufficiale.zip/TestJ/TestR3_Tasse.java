package TestJ;
import supermercato.*;
import junit.framework.TestCase;

public class TestR3_Tasse extends TestCase {

	public TestR3_Tasse(String arg0) {
		super(arg0);
	}

	private Cassa setupCassa(){
	Cassa cassa = new Cassa();
	cassa.aggiungiProdotto("P001","Acciughe",3.0);
	cassa.aggiungiProdotto("P002","Aglio",1.5);
	return cassa;
	}

	public void testIVA(){
		Cassa cassa = setupCassa();
		
    	cassa.leggi("P001");    	
    	cassa.leggi("P002");
    	cassa.leggi("P002");
    	
		double totale = cassa.totale();
        
        assertEquals(totale / 1.2,
        			 cassa.imponibile(),0.001);   	
    	
        assertEquals(totale / 6,
        				cassa.iva(),0.001);   	
	}
}

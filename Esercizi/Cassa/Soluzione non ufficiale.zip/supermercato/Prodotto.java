package supermercato;

public class Prodotto implements Pezzo {

	private String codice;
	private String nome;
	private double prezzo;
	
	public Prodotto(String codice, String nome, double prezzo) {
		this.codice = codice;
		this.nome = nome;
		this.prezzo = prezzo;
	}

	@Override
	public String getNome() {
		return nome;
	}

	@Override
	public double getPrezzo() {
			return prezzo;
	}

	@Override
	public boolean gratis() {
		return (prezzo==0.0);
	}

	String getCodice(){
		return codice;
	}

}

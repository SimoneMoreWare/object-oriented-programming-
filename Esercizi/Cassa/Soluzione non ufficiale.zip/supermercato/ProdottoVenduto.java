package supermercato;

public class ProdottoVenduto implements Pezzo{

	private Prodotto prodotto;
	private double prezzoVendita;

	public ProdottoVenduto(Prodotto p,double prezzoVendita){
		this.prodotto=p;
		this.prezzoVendita=prezzoVendita;
	}
	@Override
	public String getNome() {
		return prodotto.getNome();
	}

	@Override
	public double getPrezzo() {
		return this.prezzoVendita;
	}

	@Override
	public boolean gratis() {
		return prodotto.gratis();
	}
}

package supermercato;

import java.util.HashMap;
import java.util.LinkedList;

public class Cassa {
	
	public final static double IVA = 20.0;
	private HashMap<String,Prodotto> prodotti = new HashMap<String,Prodotto>();
	private LinkedList<ProdottoVenduto> scontrino = new LinkedList<ProdottoVenduto>();
	private double totale;
	private String codicePromozione;
	private double percPromo;
    
	/**
	 * Costruttore della Cassa
	 */
	public Cassa(){
		
		this.close();
		
	}

    /**
     * Chiude la sessione di cassa ed azzera il totale
     */
	public void close() {
		scontrino.clear();
		totale=0.0;
	}

	/**
	 * Comunica alla cassa la lettura di un codice di un
	 * prodotto. La cassa deve aggiornare il totale
	 * e restituire le informazioni sul pezzo acquistato
	 */
	public Pezzo leggi(String codice) {
		
		
		Prodotto p = prodotti.get(codice);
		if (p==null) return null;
		
		double prezzoFinale = p.getPrezzo();
		
		if(p.getCodice().equals(this.codicePromozione))
			prezzoFinale *= this.percPromo;

		totale+=prezzoFinale;
		
		ProdottoVenduto pv = new ProdottoVenduto(p,prezzoFinale);
		scontrino.add(pv);
		
		return pv;
		
	}
	
	/**
	 * restituisce il totale dei prezzi dei pezzi
	 * venduti fino ad un dato istante nella
	 * sessione corrente
	 */
	public double totale(){
		return totale;
	}

	/**
	 * restituisce l'imponibile (totale - tasse)
	 */
	public double imponibile() {
		return totale/(1.0+(IVA/100.0));
	}

	/**
	 * restituisce le tasse
	 */
	public double iva() {
		return totale - this.imponibile();
	}

	

  /**
   * Aggiunge la descrizione di un prodotto al listino
   * prezzi della cassa.
   * @param codice codice del prodotto
   * @param nome nome del prodotto
   * @param prezzo prezzo unitario (per pezzo) del prodotto
   */
  public void aggiungiProdotto(String codice, String nome, double prezzo) {
	  
	  Prodotto p = new Prodotto(codice,nome,prezzo);
	  prodotti.put(codice,p);
	  
  }

  /**
   * Attiva la promozione per il prodotto con il
   * codice specificato vendondolo alla
   * percentuale specificata
   */
  public void promozione(String codice, int percentuale) {
	  
	  this.codicePromozione=codice;
	  this.percPromo=1.0-(percentuale/100.0);
		  
  }

    
}

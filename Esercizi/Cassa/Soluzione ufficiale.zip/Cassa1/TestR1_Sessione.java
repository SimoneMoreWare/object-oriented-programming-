import supermercato.*;
import junit.framework.TestCase;

public class TestR1_Sessione extends TestCase {

	public TestR1_Sessione(String arg0) {
		super(arg0);
	}

    private Cassa setupCassa(){
		Cassa cassa = new Cassa();
		cassa.aggiungiProdotto("P001","Acciughe",3.0);
		cassa.aggiungiProdotto("P002","Aglio",1.5);
		return cassa;
    }
    
	public void testSessioneNulla(){
		Cassa cassa = new Cassa();
		// nessun prodotto letto
		double totale = cassa.totale();
		assertEquals(0.0,totale,0.0);
		cassa.close();
		totale = cassa.totale();
		assertEquals(0.0,totale,0.0);
	}
    
	public void testUnProdotto(){
		Cassa cassa = setupCassa();
		cassa.leggi("P001");
		double totale = cassa.totale(); 
		assertEquals(3.0,totale,0.001);
		cassa.close();
	}
    
	public void testSessione(){
		Cassa cassa = setupCassa();
		cassa.leggi("P001");
		cassa.leggi("P002");
		cassa.leggi("P001");
		double totale = cassa.totale();
		assertEquals(7.5,totale,0.001);
		cassa.close();
		totale = cassa.totale();
		assertEquals(totale,0.0,0.0);
	}
    
}

package supermercato;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class Cassa {
    private double totale;
    private Map listinoPrezzi = new HashMap();
    private Collection scontrino = new LinkedList();
    public static double ALIQUOTA = 0.2;
    
    private String codicePromozione;
    private double percPromozione;
    
    
	/**
	 * Costruttore della Cassa
	 */
	public Cassa(){
	}
	

    /**
     * Chiude la sessione di cassa ed azzera il totale
     */
	public void close() {
		scontrino = new LinkedList();
		totale = 0;
	}

	/**
	 * Comunica alla cassa la lettura di un codice di un
	 * prodotto. La cassa deve aggiornare il totale
	 * e restituire le informazioni sul pezzo acquistato
	 */
	public Pezzo leggi(String codice) {
		Prodotto p = (Prodotto)listinoPrezzi.get(codice);
		if(p==null) return null;
		double prezzoElemento = p.prezzo;
		if(p.codice.equals(codicePromozione)){
			prezzoElemento *= percPromozione;
		}
		totale += prezzoElemento;
		Pezzo pezzo = new PezzoVenduto(p,prezzoElemento);
		scontrino.add(pezzo);
		return pezzo;
	}
	
	/**
	 * restituisce il totale dei prezzi dei pezzi
	 * venduti fino ad un dato istante nella
	 * sessione corrente
	 */
	public double totale(){
		return totale;
	}

	/**
	 * restituisce l'imponibile (totale - tasse)
	 */
	public double imponibile() {
		return totale / (1 + ALIQUOTA);
	}

	/**
	 * restituisce le tasse
	 */
	public double iva() {
		return totale / (1 + ALIQUOTA) * ALIQUOTA;
	}

	public Collection scontrino() {
		return scontrino;
	}

  /**
   * Aggiunge la descrizione di un prodotto al listino
   * prezzi della cassa.
   * @param codice codice del prodotto
   * @param nome nome del prodotto
   * @param prezzo prezzo unitario (per pezzo) del prodotto
   */
  public void aggiungiProdotto(String codice, String nome, double prezzo) {
  	Prodotto prodotto = new Prodotto(codice,nome,prezzo);
  	this.listinoPrezzi.put(codice,prodotto);
  }

  /**
   * Attiva la promozione per il prodotto con il
   * codice specificato vendondolo alla
   * percentuale specificata
   */
  public void promozione(String codice, int percentuale) {
  	this.codicePromozione = codice;
  	this.percPromozione = (100.0-percentuale)/100.0;
  }

    
}

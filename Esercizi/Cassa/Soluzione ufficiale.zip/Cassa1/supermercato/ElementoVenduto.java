


package supermercato;
public class ElementoVenduto implements Pezzo {
	
	private Prodotto prodotto;
	private double prezzo;
	
	public ElementoVenduto(Prodotto prodotto, double prezzo){
		this.prodotto = prodotto;
		this.prezzo = prezzo;
	}
	public String getNome() {
		return prodotto.nome;
	}

	public double getPrezzo() {
		return prezzo;
	}

	public boolean gratis(){
		return prezzo == 0.0;
	}
}

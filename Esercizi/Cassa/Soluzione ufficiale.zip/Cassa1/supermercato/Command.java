package supermercato;
import org.polito.po.Console;
import java.util.Iterator;

public class Command {
	private Console console;
	private CassaSupermercato cassa;

	public Command(CassaSupermercato cassa) {
		this.cassa = cassa;
		this.console = new Console();
	}
	
	public Command(CassaSupermercato cassa, Console console) {
		this.cassa = cassa;
		this.console = console;
	}
	
	public void execute() {
		while(true){
			console.print("> ");
			String cmd = console.readLine();
			if(cmd.equals("CLOSE")){
				console.println("---- Scontrino ----");
				Iterator scontrino = cassa.scontrino().iterator();
				while(scontrino.hasNext()){
					Pezzo elemento = (Pezzo)scontrino.next();
					console.print(elemento.getNome()+" ");
					if(elemento.gratis())
						console.println("*gratis*");
					else
						console.println(""+elemento.getPrezzo());
					
				}
				if(cassa.sconto()!=0){
					console.println("Senza sconto: " + cassa.senzaSconto());
					console.println("sconto: " + cassa.sconto());
				}
				console.println("Senza IVA: " + cassa.imponibile());
				console.println("  IVA 20%: " + cassa.iva());
				console.println("Totale: " + cassa.totale());
				cassa.close();
			}else
			if(cmd.startsWith("SCONTO")){
				String par = cmd.substring(7);
				cassa.sconto(Integer.parseInt(par));
			}else
			if(cmd.startsWith("PROMO")){
				String par = cmd.substring(6);
				cassa.promo(par);
			}else
			if(cmd.equals("QUIT")){
				break;
			}else{
				Pezzo elemento = cassa.leggi(cmd);
				console.println(elemento.getNome()
						+" "+elemento.getPrezzo());
				
			}
		}
	}
}

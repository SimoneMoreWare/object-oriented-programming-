
package supermercato;
public class Prodotto {
	String codice;
	String nome;
	double prezzo;
	
	Prodotto(String codice, String nome, double prezzo){
		this.codice = codice;
		this.nome = nome;
		this.prezzo	= prezzo;
	}
}
package supermercato;

public interface Item {
	String getNome();
	double getPrezzo();
	boolean gratis();
}

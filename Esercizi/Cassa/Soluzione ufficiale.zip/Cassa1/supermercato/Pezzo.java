package supermercato;

/**
 * Rappresenta un pezzo venduto.
 * E' un esemplare di un certo prodotto.
 */
public interface Pezzo {
	/**
	 * Nome del prodotto di cui il pezzo venduto
	 * � un esemplare.
	 */
	String getNome();
	
	/**
	 * Prezzo a cui viene venduto questo pezzo
	 */
	double getPrezzo();
	
	/**
	 * Indica se il pezzo � gratis, ovvero
	 * se il prezzo � 0 (zero)
	 */
	boolean gratis();
}

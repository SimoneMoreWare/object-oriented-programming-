package supermercato;
import java.util.Collection;


public interface CassaSupermercato {
	Pezzo leggi(String codice);
	void close();
	double totale();
	double imponibile();
	double iva();
	double senzaSconto();
	double sconto();
	void sconto(int sconto);
	int percentoSconto();
	Collection scontrino();
	void promo(String string);
}

import fiji.io.*;

/**
 * Ordina un array con l'algoritmo SelectSort
 * 
 * @author  Pasquale Foggia
 * @version Maggio 2001
 */
public class SelectSort
{

  public static void main(String args[])
    { int a[] = leggiArray();
      
      ordina(a);

      int i;
      System.out.print("Array ordinato: ");
      for(i=0; i<a.length; i++)
        System.out.print(" "+a[i]);
      
      System.out.println();
    }

  /**
   * Legge un array di interi da tastiera
   */
  static int[] leggiArray()
    { SimpleReader in=new SimpleReader();
      System.out.print("Numero di elementi dell'array? ");
      int n=in.readInt();
      int a[]=new int[n];
      int i;
      for(i=0; i<n; i++)
        { System.out.print("Inserisci l'elemento "+i+": ");
          a[i]=in.readInt();
        }
      return a;
    }
     
  /**
   * Ordina in senso crescente gli elementi di un array usando
   * l'algoritmo di ordinamento per selezione
   */ 
  static void ordina(int a[])
    { int n=a.length;
      int i, j;
      for(i=0; i<n-1; i++)
        { int jmin=i;
          for(j=i+1; j<n; j++)
            { if (a[j] < a[jmin])
                jmin = j;
            }
          scambia(a, i, jmin);
        }
     }

  /**
   * Scambia di posto due elementi di un array
   */
  static void scambia(int a[], int i, int j)
    { int tmp=a[i];
      a[i]=a[j];
      a[j]=tmp;
    }   
}

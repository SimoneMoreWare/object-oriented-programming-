import fiji.io.*;

/**
 * Gestione di una cartella della tombola...
 * 
 * @author  Pasquale Foggia
 * @version Maggio 2001
 */
public class Tombola
{ static final int RIGHE=3, COLONNE=5;
  static final int MIN_VINCITA=3;
  static final int TOMBOLA=RIGHE*COLONNE;

  public static void main(String args[])
    { SimpleReader in=new SimpleReader();

      int cartella[][] = leggiCartella();
      boolean usciti[][] = new boolean[RIGHE][COLONNE];

      // Nel seguente array viene memorizzato il numero di
      // elementi usciti per ciascuna riga.
      int numUsciti[] = new int[RIGHE]; 


      int numero, r, vincita;
      do {
        System.out.print("Inserisci il numero uscito (0 per terminare): ");
        numero = in.readInt();
        if (numero == 0)
            break; // Esce subito dal ciclo

        r = controllaNumero(numero, cartella, usciti, numUsciti);
        if (r>=0) // r � la riga in cui si trovava il numero
          { vincita=controllaVincita(numUsciti, r);
            if (vincita>0)
              visualizzaVincita(cartella, usciti, r, vincita);
          }

      } while (numero!=0);
    }
  

  /**
   * Legge una cartella da tastiera
   */
  static int[][] leggiCartella()
    { int cart[][]=new int[RIGHE][COLONNE];
      int i, j;
      SimpleReader in=new SimpleReader();

      for(i=0; i<RIGHE; i++)
         { System.out.print("Inserisci i "+COLONNE+" numeri della riga "+
                            (i+1)+": ");
           for(j=0; j<COLONNE; j++)
              cart[i][j]=in.readInt();
         }

      return cart;
    }  

  /**
   * Controlla se un numero � presente nella cartella. In caso
   * affermativo, marca la posizione corrispondente dell'array
   * 'usciti', incrementa l'elemento corrispondente nell'array
   * 'numUsciti' e restituisce l'indice della riga in cui
   * si trovava il numero.
   * Se il numero non � trovato, restituisce -1.
   */
  static int controllaNumero(int numero, int cartella[][], 
                             boolean usciti[][], int numUsciti[])
    { 
      // Cerca il numero nella cartella
      boolean trovato;
      int i, j, riga=-1, col=-1;
      trovato=false;
      for(i=0; !trovato && i<RIGHE; i++)
         for(j=0; !trovato && j<COLONNE; j++)
            { if (!usciti[i][j] && cartella[i][j] == numero)
                 { trovato=true;
                   riga = i;
                   col = j;
                 }
            }

       if (!trovato)
          return -1;

       usciti[riga][col] = true;
       numUsciti[riga] ++;
       return riga;
    }         

  /**
   * Controlla se si � realizzata una nuova vincita...
   * In caso affermativo restituisce un numero che indica
   * il tipo di vincita: 3 per il terno, 4 per la quaterna etc.
   * In caso negativo, restituisce 0.
   */
  static int controllaVincita(int numUsciti[], int riga)
    { 
      // Calcola il minimo valore su una riga
      int min = minimo(numUsciti);
      if (min == COLONNE)
        return TOMBOLA;

      // Calcola il massimo valore su una riga
      // escludendo la riga dell'ultimo numero uscito...
      numUsciti[riga] --;  // Modifica temporaneamente il vettore...
      int oldMax = massimo(numUsciti);
      numUsciti[riga] ++;  // Ripristina il vettore

      if (numUsciti[riga] > oldMax && numUsciti[riga] >= MIN_VINCITA)
        return numUsciti[riga];
      else
        return 0;
    }

  /**
   * Visualizza una vincita.
   */
  static void visualizzaVincita(int cartella[][], boolean usciti[][], 
                                int riga, int vincita)
    { if (vincita == TOMBOLA)
        { System.out.println("Tombola!");
        }
      else
        { switch (vincita)
            { case 3: System.out.print("Terno"); break;
              case 4: System.out.print("Quaterna"); break;
              case 5: System.out.print("Quintina"); break;
              default: System.out.print("Vincita di "+vincita+" numeri");
                       break;
            }
          System.out.println(" sulla riga"+(riga+1));
          System.out.print("I numeri sono: ");
          int i;
          for(i=0; i<COLONNE; i++)
            if (usciti[riga][i])
              System.out.print(" "+cartella[riga][i]);

          System.out.println();
        }
    }


   /**
    * Calcola il massimo di un array
    */
   static int massimo(int a[])
      { int i, m;
        m=a[0];
        for(i=1; i<a.length; i++)
          if (a[i]>m)
            m=a[i];
        return m;
      }

   /**
    * Calcola il minimo di un array
    */
   static int minimo(int a[])
      { int i, m;
        m=a[0];
        for(i=1; i<a.length; i++)
          if (a[i]<m)
            m=a[i];
        return m;
      }

}

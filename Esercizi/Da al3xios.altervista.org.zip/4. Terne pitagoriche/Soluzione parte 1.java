
/**
 * Conta il numero di terne pitagoriche.
 * 
 * @author Pasquale Foggia
 * @version Maggio 2001
 */
public class ContaTerne
{ 	final static int MAX=100;
	

	public static void main(String args[])
	{ int a, b, c;
      int conta;
      
      conta=0;
      for(a=1; a<=MAX; a++)
        for(b=a+1; b<=MAX; b++)
           for(c=b+1; c<=MAX; c++)
              { if (ternaPitagorica(a,b,c))
                  conta++;
              }
      System.out.println("Il numero di terne �: "+conta);
	}

    /**
     * Controlla se tre numeri formano una terna pitagorica
     */
	static boolean ternaPitagorica(int a, int b, int c)
    { return  a*a + b*b == c*c;
    }
}

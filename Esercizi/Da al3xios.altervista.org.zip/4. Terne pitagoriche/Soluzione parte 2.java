
/**
 * Conta il numero di terne pitagoriche in cui 'a' � 
 * un numero primo.
 * 
 * @author  Pasquale Foggia
 * @version Maggio 2001
 */
public class StampaTerne
{  final static int MAX=100;

	public static void main(String args[])
	{ int a, b, c;

      for(a=1; a<=MAX; a++)
        for(b=a+1; b<=MAX; b++)
           for(c=b+1; c<=MAX; c++)
              { if (ternaPitagorica(a,b,c) && primo(a))
                  System.out.println(a+" "+b+" "+c);
              }
	}

    /**
     * Controlla se tre numeri formano una terna pitagorica
     */
	static boolean ternaPitagorica(int a, int b, int c)
    { return  a*a + b*b == c*c;
    }

   /**
    * Controlla se un numero � primo
    */
   static boolean primo(int n)
     { // Un numero n � primo se non ha altri divisori oltre a 1 e se stesso.
       // 'i' � divisore di 'n' se il resto della divisione n/i � 0.
       int i;
       for(i=2; i<n; i++)
         if (n % i == 0)
            return false;
       return true;
     }
}

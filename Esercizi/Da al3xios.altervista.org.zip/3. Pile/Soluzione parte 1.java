
/**
 * Classe che rappresenta una pila di interi
 * 
 * @author  P. Foggia
 * @version Giugno 2001
 */
public class Pila
{ private int n;   // Numero di elementi nella pila
  private int a[]; // Elementi contenuti nella pila

  //-------------------- Interfaccia dell'oggetto ---------------------
  
  /**
   * Costruttore dell'oggetto. Richiede di specificare come
   * parametro il numero massimo di elementi inseribili
   * nella pila
   */
  public Pila(int nmax)
    { n=0;
      a=new int[nmax];
    }

  /**
   * Inserisce un elemento nella pila
   */
  public void push(int x)
    { a[n++] = x;
    }

  /**
   * Rimuove un elemento dalla pila. 
   */
  public void pop()
    { if (n>0)
        n--;
    }

  /**
   * Restituisce il valore in cima alla pila
   */
  public int top()
    { return a[n-1];
    }
  
  /**
   * Indica se la pila � vuota.
   */
  public boolean empty()
    { return n==0;
    }

  /**
   * Indica se la pila � piena.
   */
  public boolean full()
    { return n == a.length;
    }
}

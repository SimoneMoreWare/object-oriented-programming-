import fiji.io.*;

/**
 * Inverte un elenco di numeri usando una pila.
 * 
 * @author  P. Foggia
 * @version Giugno 2001
 */
public class InvertiElenco
{

  public static void main(String args[])
    { SimpleReader in=new SimpleReader();

      System.out.print("Quanti numeri vuoi inserire? ");
      int n=in.readInt();

      // Crea un oggetto chiamando il costruttore
      Pila pila=new Pila(n);

      int i;
      for(i=0; i<n; i++)
        { System.out.print("Elemento "+(i+1)+": ");
          int x=in.readInt();

          // Inserisce l'elemento nella pila
          pila.push( x );
        }

      System.out.print("Elementi (in ordine inverso): ");
      // Finch� la pila non � vuota...
      while (! pila.empty() )
        { // ... stampa l'ultimo elemento...
          System.out.print(" "+pila.top());
          
          // ... e lo rimuove.
          pila.pop();
        }

      System.out.println();
      System.out.println();    
    }
  
  
}

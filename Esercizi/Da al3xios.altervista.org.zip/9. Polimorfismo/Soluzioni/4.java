
/**
 * Questa classe descrive oggetti in grado di
 * calcolare la funzione 'seno'.
 * 
 * @author  P. Foggia
 * @version Giugno 2001
 */
public class FunzioneSeno extends Funzione
{

  /**
   * Restituisce il seno di x, dove x
   * e' espresso in radianti.
   */
  public double calcola(double x)
    { return Math.sin(x);

    }
  
  
}

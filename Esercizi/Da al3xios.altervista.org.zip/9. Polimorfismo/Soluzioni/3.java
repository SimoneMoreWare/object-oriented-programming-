
/**
 * Questo programma crea i grafici di alcune funzioni,
 * usando le classi GraficoFunzione e FunzioneXXX
 * 
 * @author  
 * @version (a version number or a date)
 */
public class CreaGrafici
{

  public static void main(String args[])
    { Funzione f;
      GraficoFunzione g;

      f=new FunzioneSeno();
      g=new GraficoFunzione("Seno di x", f, -4.5, 4.5);
   
      f=new FunzioneSinc();
      g=new GraficoFunzione("Sinc di x", f, -10.0, 10.0);

      f=new FunzioneLogaritmo();
      g=new GraficoFunzione("Logaritmo naturale di x", f, 0.02, 60.0);

      f=new FunzioneLogaritmo(10.0);
      g=new GraficoFunzione("Logaritmo decimale di x", f, 0.02, 60.0);

    }
  
  
}

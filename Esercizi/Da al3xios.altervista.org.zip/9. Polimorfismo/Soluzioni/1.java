
/**
 * Questa classe rappresenta una generica funzione,
 * in grado di calcolare il valore della y a partire 
 * dal valore della x. In realt� le funzioni vere e proprie
 * saranno definite da classi derivate che andranno a 
 * modificare l'implementazione del metodo calcola().
 *
 * NOTA PER GLI 'ESPERTI' DI JAVA: sarebbe pi� consono
 * allo spirito del linguaggio definire Funzione con
 * un costrutto 'interface'.
 * 
 * @author  P. Foggia
 * @version Giugno 2001
 */
public class Funzione
{

  /**
   * Calcola la y in funzione della x
   */
  public double calcola(double x)
    { return 0.0;
    }  
  
}

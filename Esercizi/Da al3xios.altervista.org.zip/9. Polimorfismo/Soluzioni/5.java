
/**
 * Definisce oggetti in grado di calcolare la 
 * funzione 'sinc'.
 * 
 * @author  P. Foggia
 * @version Giugno 2001
 */
public class FunzioneSinc extends Funzione
{

  /**
   * Restituisce sinc(x), definita come sin(x)/x.
   * x e' espresso in radianti.
   */
  public double calcola(double x)
    { if (Math.abs(x) < 1e-12)
        return 1.0;
      else
        return Math.sin(x)/x;
    }
  
  
}


/**
 * Descrive oggetti in grado di calcolare il logaritmo.
 * 
 * @author  P. Foggia
 * @version Giugno 2001
 */
public class FunzioneLogaritmo extends Funzione
{ /**
   * Logaritmo naturale della base.
   */
  private double logBase;

  /**
   * Costruttore di default. Imposta la base
   * pari a 'e'.
   */
  public FunzioneLogaritmo()
    { logBase = 1.0;
    }

  /**
   * Costruttore. Richiede come parametro la base del logaritmo.
   */
  public FunzioneLogaritmo(double base)
    { logBase = Math.log(base);
    }

  /**
   * Restituisce il logaritmo di x nella base scelta tramite
   * il costruttore.
   */
  public double calcola(double x)
    { return Math.log(x)/logBase;
    }
  
}

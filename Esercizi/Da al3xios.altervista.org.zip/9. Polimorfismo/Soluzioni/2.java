import fiji.grafica.*;
import java.awt.*;
import java.text.*;

/**
 * Questa classe rappresenta oggetti in grado di visualizzare il
 * grafico di una funzione.
 * 
 * @author  P. Foggia
 * @version Giugno 2001
 */
public class GraficoFunzione
{
  private  static final int WIDTH=640,
                            HEIGHT=480;
  private static final int XPAD=60,
                           YPAD=60;
  private static final int TICK = 4;
  private static final int POINTS = 320;
  private  Color coloreAssi = Color.green,
                 coloreEtichette = Color.black,
                 coloreGrafico = Color.blue;

  private DrawingFrame df;

  private double xmin, xmax, ymin, ymax;


  /**
   * Costruttore.
   */
  public GraficoFunzione(String titolo, Funzione f, double x1, double x2)
    { df = new DrawingFrame(titolo, WIDTH, HEIGHT);
      xmin = x1;
      xmax = x2;

      double yBounds[] = calcolaEstremi(f, x1, x2);
      ymin=yBounds[0];
      ymax=yBounds[1];
      // System.out.println(titolo+" "+xmin+", "+xmax+", "+ymin+", "+ymax);
      disegnaAssi();
      disegnaFunzione(f);
    }

  /**
   * Calcola il valore minimo e il valore massimo assunti dalla funzione
   * in un intervallo di valori x.
   * Restituisce un array in cui il primo elemento rappresenta il
   * valore minimo, e il secondo il valore massimo di y.
   */
  private double[] calcolaEstremi(Funzione f, double x1, double x2)
    { 
      double dx = (x2-x1)/POINTS;
      double y = f.calcola(x1);
      double y1=y, y2=y;
      double x;
      for(x=x1; x<=x2; x+=dx)
        { y=f.calcola(x);
          if (y<y1)
            y1=y;
          if (y>y2)
            y2=y;
        }
      double v[]={ y1, y2};
      return v;
    }  

  /**
   * Disegna gli assi cartesiani e le relative etichette.
   */
  private void    disegnaAssi()
     { double xa, ya;
       xa = Math.max(xmin, 0.0);
       ya = Math.max(ymin, 0.0);

       int ixa = mapX(xa);
       int iya = mapY(ya);
       int ixmin = mapX(xmin);
       int iymin = mapY(ymin);
       int ixmax = mapX(xmax);
       int iymax = mapY(ymax);
  
       df.setColor(coloreAssi);

       // Disegna gli assi
       df.drawLine(ixa, iymin, ixa, iymax);
       df.drawLine(ixmin, iya, ixmax, iya);

       // Disegna le tacchette
       double tickX = tickSpace(xmax - xmin);
       double tickY = tickSpace(ymax - ymin);

       double x, y;
       int ix, iy;

       for(x=Math.ceil(xmin/tickX)*tickX; x<=xmax; x+=tickX)
         { ix = mapX(x);
           df.drawLine(ix, iya, ix, iya+TICK);
         }
       for(y=Math.ceil(ymin/tickY)*tickY; y<=ymax; y+=tickY)
         { iy = mapY(y);
           df.drawLine(ixa, iy, ixa-TICK, iy);
         }


       // Un oggetto della classe NumberFormat server a convertire
       // un numero in una stringa specificando varie opzioni
       // per la conversione. In questo caso si usa per fissare il
       // numero massimo di cifre decimali.       
       NumberFormat nf = NumberFormat.getInstance();
       nf.setMaximumFractionDigits(6);

       // Un oggetto della classe FontMetrics serve a sapere
       // quanti pixels sono occupati da un testo.
       FontMetrics fm = df.getGraphics().getFontMetrics();
       int ascent = fm.getAscent();
       

       // Scrive le etichette

       df.setColor(coloreEtichette);
       for(x=Math.ceil(xmin/tickX)*tickX; x<=xmax; x+=tickX)
         { ix = mapX(x);
           String xstr=nf.format(x);
           df.drawString(xstr, ix-fm.stringWidth(xstr)/2, iya+2*TICK+ascent);
         }
       for(y=Math.ceil(ymin/tickY)*tickY; y<=ymax; y+=tickY)
         { iy = mapY(y);
           String ystr=nf.format(y);
           df.drawString(ystr, ixa-2*TICK-fm.stringWidth(ystr), iy);
         }

     }

  /** 
   * Disegna il grafico della funzione
   */
  private void disegnaFunzione(Funzione f)
     { double x, y;
       int ix, iy, ix0, iy0;
       df.setColor(coloreGrafico);
       x=xmin;
       y=f.calcola(x);
       ix0=mapX(x);
       iy0=mapY(y);
       double dx=(xmax-xmin)/POINTS;
       for(x=xmin+dx; x<=xmax; x+=dx)
         { y=f.calcola(x);
           ix = mapX(x);
           iy = mapY(y);
           df.drawLine(ix0, iy0, ix, iy);
           ix0 = ix;
           iy0 = iy;
         }
  }

  /**  
   * Calcola la posizione x in coordinate di schermo corrispondente
   * a una data x nelle coordinate del piano cartesiano
   */
  private int mapX(double x)
      { return XPAD+(int)((WIDTH-XPAD-XPAD/2)*(x-xmin)/(xmax-xmin)); 
      }

  /**  
   * Calcola la posizione y in coordinate di schermo corrispondente
   * a una data y nelle coordinate del piano cartesiano
   */
  private int mapY(double y)
      { return YPAD/2+(int)((HEIGHT-YPAD-YPAD/2)*(ymax-y)/(ymax-ymin)); 
      }

  /**
   * Calcola la spaziatura ottimale per i marcatori sugli assi
   */
  private double tickSpace(double delta)
    { // Trova la potenza di 10 pi� vicina...
      double log10 = Math.log(delta)/Math.log(10.0);
      double space = Math.pow(10.0, Math.floor(log10));

      double r = Math.floor(delta / space);
      if (r <= 2)
        space = space/5.0;
      else if (r<=5)
        space = space/2.0;

      return space;
    }          
   
}

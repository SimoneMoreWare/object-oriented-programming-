import fiji.io.*;
import fiji.grafica.*;
import java.awt.*;

/**
 * Visualizza un istogramma dei voti in forma grafica.
 * 
 * @author  Pasquale Foggia
 * @version Maggio 2001
 */
public class IstogrammaGrafico
{ final static int VOTO_MIN = 18,
                   VOTO_MAX = 30;

  public static void main(String args[])
    { int voti[] = leggiArray();
      int freq[] = calcolaFrequenze(voti);
      visualizzaIstogramma(freq);
    }



  static int[] leggiArray()
    { SimpleReader in=new SimpleReader();

      System.out.print("Quanti esami hai sostenuto? ");
      int n=in.readInt();

      int a[] = new int[n];

      int i;
      for(i=0; i<n; i++)
        { System.out.print("Inserisci il voto dell'esame "+(i+1)+": ");
          a[i] = in.readInt();
        }

      return a;
    }

  /**
   * Calcola la frequenza di occorrenza di ciascun voto. Restituisce
   * un array in cui l'elemento di indice 'i' rappresenta il numero
   * di volte che � stato ottenuto il voto VOTO_MIN+i .
   */  
  static int[] calcolaFrequenze(int voti[])  
    { int f[] = new int[VOTO_MAX - VOTO_MIN + 1];

      int i, voto;
      for(i=0; i<voti.length; i++)
        { voto = voti[i];
          f[voto - VOTO_MIN] ++;
        }

      return f;
    }

  static void visualizzaIstogramma(int freq[])
    { // Crea un oggetto della classe DrawingFrame per disegnare...
      DrawingFrame df=new DrawingFrame("Istogramma dei voti", // Titolo
                                       640, // Larghezza
                                       480  // Altezza
                                     );

      final int Y0=30, DY=30, H=20;
      final int X0=5, X1=30, W=18;
      int i;
      for(i=0; i<freq.length; i++)
         { int y = Y0+i*DY;
           df.setColor(Color.black);
           df.drawString(""+(i+VOTO_MIN), X0, y+H-3);
           df.drawRect(X1, y, W*freq[i], H);
           df.setColor(Color.cyan);
           df.fillRect(X1+1, y+1, W*freq[i]-2, H-2);
           
         }
    }


  
  
}

import fiji.io.*;

/**
 * Visualizza un istogramma con le frequenze di occorrenza dei voti.
 * 
 * @author  Pasquale Foggia
 * @version Maggio 2001
 */
public class Istogramma
{ final static int VOTO_MIN = 18,
                   VOTO_MAX = 30;

  public static void main(String args[])
    { int voti[] = leggiArray();
      int freq[] = calcolaFrequenze(voti);
      visualizzaIstogramma(freq);
    }



  static int[] leggiArray()
    { SimpleReader in=new SimpleReader();

      System.out.print("Quanti esami hai sostenuto? ");
      int n=in.readInt();

      int a[] = new int[n];

      int i;
      for(i=0; i<n; i++)
        { System.out.print("Inserisci il voto dell'esame "+(i+1)+": ");
          a[i] = in.readInt();
        }

      return a;
    }

  /**
   * Calcola la frequenza di occorrenza di ciascun voto. Restituisce
   * un array in cui l'elemento di indice 'i' rappresenta il numero
   * di volte che � stato ottenuto il voto VOTO_MIN+i .
   */  
  static int[] calcolaFrequenze(int voti[])  
    { int f[] = new int[VOTO_MAX - VOTO_MIN + 1];

      int i, voto;
      for(i=0; i<voti.length; i++)
        { voto = voti[i];
          f[voto - VOTO_MIN] ++;
        }

      return f;
    }

  static void visualizzaIstogramma(int freq[])
    { int i, j;
      for(i=0; i<freq.length; i++)
         { System.out.print("Voto "+(i+VOTO_MIN)+": ");
           for(j=0; j<freq[i]; j++)
              { System.out.print("*");
              }
           System.out.println();
         }
    }
}

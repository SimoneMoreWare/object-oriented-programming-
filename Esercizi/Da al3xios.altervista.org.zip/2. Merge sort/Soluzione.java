import fiji.io.*;

/**
 * Ordina un array con l'algoritmo MergeSort
 * 
 * @author  Pasquale Foggia
 * @version Maggio 2001
 */
public class MergeSort
{

  public static void main(String args[])
    { int a[] = leggiArray();
      
      ordina(a, 0, a.length-1);

      int i;
      System.out.print("Array ordinato: ");
      for(i=0; i<a.length; i++)
        System.out.print(" "+a[i]);
      
      System.out.println();
    }

  /**
   * Legge un array di interi da tastiera
   */
  static int[] leggiArray()
    { SimpleReader in=new SimpleReader();
      System.out.print("Numero di elementi dell'array? ");
      int n=in.readInt();
      int a[]=new int[n];
      int i;
      for(i=0; i<n; i++)
        { System.out.print("Inserisci l'elemento "+i+": ");
          a[i]=in.readInt();
        }
      return a;
    }
     
  /**
   * Ordina in senso crescente gli elementi di un array usando
   * l'algoritmo di ordinamento per fusione
   */ 
  static void ordina(int a[], int l, int u)
    { if (l>=u)
        return;
      int m=(l+u)/2;
      ordina(a, l, m);
      ordina(a, m+1, u);
      fusione(a, l, m, u);
    }

  /**
   * Fonde due parti ordinate di uno stesso array
   * in modo da preservare l'ordinamento.
   * Le parti hanno indici che vanno da l a m (incluso)
   * e da m+1 a u.
   */
  static void fusione(int a[], int l, int m, int u)
    { int i=l;
      int j=m+1;
      int b[]=new int[u-l+1];
      int k=0;

      while (k < u-l+1)
         { if (j>u || (i<=m && a[i]<a[j]))
             b[k++] = a[i++];
           else
             b[k++] = a[j++];
         }

      for(k=0; k<u-l+1; k++)
        a[l+k] = b[k];
     }
}

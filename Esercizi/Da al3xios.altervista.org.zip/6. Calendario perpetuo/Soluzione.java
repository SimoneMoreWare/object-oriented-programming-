import fiji.io.*;

/**
 * Calcola il giorno della settimana corrispondente a una data
 * 
 * @author  Pasquale Foggia
 * @version Maggio 2001
 */
public class CalendarioPerpetuo
{

  public static void main(String args[])
    { SimpleReader in=new SimpleReader();

      System.out.println("Inserisci la data, specificando giorno mese e anno"+
                         "separati da spazi. Esempio: 25 12 2002");
      System.out.print("Data? ");
      int giorno = in.readInt();
      int mese = in.readInt();
      int anno = in.readInt();

      int giorniTrascorsi = giorniAnno(anno) + giorniMese(mese) + giorno-1;
      if (bisestile(anno) && mese>2)
         giorniTrascorsi++;

      int giornoSettimana = giorniTrascorsi % 7;

      stampaGiornoSettimana(giornoSettimana);
    }
  
  static boolean bisestile(int anno)
    { return anno%4==0 && (anno%100!=0 || anno%400==0);
    }

  /**
   * Giorni trascorsi dal 1/01/1900 al primo gennaio dell'anno
   * passato come parametro.
   */
  static int giorniAnno(int anno)
    { int a, giorni;
      giorni = (anno-1900)*365;
      for(a=1900; a<anno; a+=4)
        { if (bisestile(a))
            giorni ++;
        }
      return giorni;  
    }

  /**
   * Giorni trascorsi dal primo gennaio al primo del mese
   * passato come parametro. Non considera gli anni bisestili
   */
  static int giorniMese(int mese)
    { switch(mese)
        { case  1:  return 0;
          case  2:  return 31;
          case  3:  return 31+28;
          case  4:  return 31+28+31;
          case  5:  return 31+28+31+30;
          case  6:  return 31+28+31+30+31;
          case  7:  return 31+28+31+30+31+30;
          case  8:  return 31+28+31+30+31+30+31;
          case  9:  return 31+28+31+30+31+30+31+31;
          case 10:  return 31+28+31+30+31+30+31+31+30;
          case 11:  return 31+28+31+30+31+30+31+31+30+31;
          case 12:  return 31+28+31+30+31+30+31+31+30+31+30;
          default:  System.out.println("Mese non valido: "+mese);
                    return -1;
        }
    }

  
  static void stampaGiornoSettimana(int g)
    { switch(g)
        { case 0: System.out.println("Luned�");  break;
          case 1: System.out.println("Marted�");  break;
          case 2: System.out.println("Mercoled�");  break;
          case 3: System.out.println("Gioved�");  break;
          case 4: System.out.println("Venerd�");  break;
          case 5: System.out.println("Sabato");  break;
          case 6: System.out.println("Domenica");  break;
          default:  System.out.println("Giorno non valido: "+g);
                    break;
        }
    }
          
}

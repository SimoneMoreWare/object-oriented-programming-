import fiji.io.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Risolve il problema della torre di Hanoi, con
 * visualizzazione grafica.
 * @author  Pasquale Foggia
 * @version Maggio 2001.
 */
public class TorreDiHanoiGrafica extends Canvas
{

 static TorreDiHanoiGrafica window;
 static int pioli[][];
 static int libero, x, y;
 
 Image img=null;
 
 final static int DELAY=10,
                  X_SPEED=8,
                  Y_SPEED=6;
 
 final static int PIOLI=3,
                  MAX_DISCHI=10,
                  ALTEZZA=20,
                  LARGHEZZA=15,
                  OFS_LARGHEZZA=40,
                  DIST_Y=25,
                  DIST_X=OFS_LARGHEZZA+MAX_DISCHI*LARGHEZZA + 5;

 public static void main(String args[])
    { SimpleReader in=new SimpleReader();

      System.out.print("Inserisci il numero di dischi (max: "+MAX_DISCHI+
                            "): ");
      int n=in.readInt();
      
      libero=0;
      pioli=new int[PIOLI][n];
      int i;
      for(i=0; i<n; i++)
        { pioli[0][i]=n-i+1;
          pioli[1][i]=0;
          pioli[2][i]=0;
        }

      Frame f=new Frame("Torre di Hanoi");
      window = new TorreDiHanoiGrafica();
      f.add("Center", window);
      f.setSize(640, 400);
      f.show();
      f.toFront();
      f.addWindowListener(new WindowAdapter() {
        public void windowClosing(WindowEvent ev) {
          System.exit(0);
        }
      });
      

      hanoi(n, 'A', 'C');
    }

  static char terzoPiolo(char p1, char p2)
    { if (p1 != 'A' && p2!='A')
        return 'A';
      else if (p1!='B' && p2!='B')
        return 'B';
      else
        return 'C';
    }

  static void muovi(char da, char a)
    { afferra(da);
      sposta(da, a);
      deponi(a);
    }

  static void hanoi(int n, char da, char a)
    { if (n<=1)
        muovi(da, a);
      else
        { char terzo=terzoPiolo(da, a);
          hanoi(n-1, da, terzo);
          muovi(da, a);
          hanoi(n-1, terzo, a);
        }
    }
    
  public void paint(Graphics g)
    { Dimension dim=getSize();
      if (img==null || img.getWidth(null) != dim.width 
          || img.getHeight(null) != dim.height)
        { img=createImage(dim.width, dim.height);
        }
      disegna(img.getGraphics());
      g.drawImage(img, 0, 0, null);
    }
 
  void disegna(Graphics g)
    { Dimension dim=getSize();
      g.setColor(Color.white);
      g.fillRect(0,0, dim.width, dim.height);
      g.setColor(Color.gray);
      Point p1=posizione('A', -1);
      Point p2=posizione('B', MAX_DISCHI-1);
      Point p3=posizione('C', -1);
      g.fillRect(p1.x-DIST_X/2, p1.y-ALTEZZA/2, p3.x-p1.x+DIST_X, ALTEZZA);
      int i;
      for(i=0; i<PIOLI; i++)
        g.fillRect(p1.x+i*DIST_X-LARGHEZZA/4, p2.y-DIST_Y/2,
                   LARGHEZZA/2, p1.y-p2.y+DIST_Y/2);
                   
      for(i=0; i<PIOLI; i++)
        { int j;
          for(j=0; j<pioli[i].length; j++)
            { if (pioli[i][j]==0)
                 continue;
              Point p=posizione((char)('A'+i), j);
              g.setColor(colore(pioli[i][j]));
              int w=pioli[i][j]*LARGHEZZA + OFS_LARGHEZZA;
              g.fillRect(p.x-w/2, p.y-ALTEZZA/2, w, ALTEZZA);
            }
        }
        
      if (libero>0)
        { g.setColor(colore(libero));
          int w=libero*LARGHEZZA + OFS_LARGHEZZA;
          g.fillRect(x-w/2, y-ALTEZZA/2, w, ALTEZZA);
        }

    }
    
  static Point posizione(char piolo, int altezza)
    { Point p=new Point();
      p.x = (piolo-'A')*DIST_X + DIST_X/2 + 2*LARGHEZZA;
      p.y = (MAX_DISCHI-altezza+1)*DIST_Y + DIST_Y/2 + 2*ALTEZZA;
      return p;
    }
    
  static Color colore(int dim)
    { switch(dim%3) {
         case 0: return Color.blue;
         case 1: return Color.red;
         case 2: return Color.green;
         default: return Color.blue;
      }
    }
    
  static void afferra(char da)
    { int i=da-'A';
      int j;
      for(j=pioli[i].length-1; pioli[i][j]==0; j--)
        ;
      Point p1=posizione(da, j);
      Point p2=posizione(da, MAX_DISCHI);
      x= p1.x;
      y= p1.y;
      libero = pioli[i][j];
      pioli[i][j]=0;
      while (y> p2.y)
        { y-= Y_SPEED;
          if (y < p2.y)
            y=p2.y;
          window.paint(window.getGraphics());
          try { Thread.sleep(DELAY); } catch (Exception e) { }
        }
    }
    
  static void sposta(char da, char a)
    { Point p1=posizione(da, MAX_DISCHI);
      Point p2=posizione(a, MAX_DISCHI);
      y=p1.y;
      if (p1.x < p2.x)
        { for(x=p1.x; x<p2.x; x+=X_SPEED)
            { window.paint(window.getGraphics());
              try { Thread.sleep(DELAY); } catch (Exception e) { }
            }
          x = p2.x; 
          window.paint(window.getGraphics());
        }
      else
        { for(x=p1.x; x>p2.x; x-=X_SPEED)
            { window.paint(window.getGraphics());
              try { Thread.sleep(DELAY); } catch (Exception e) { }
            }
          x = p2.x; 
          window.paint(window.getGraphics());
        }
      
    }
    
  static void deponi(char a)
    { int i=a-'A';
      int j;
      for(j=0; pioli[i][j]!=0; j++)
        ;
      Point p1=posizione(a, MAX_DISCHI);
      Point p2=posizione(a, j);
      x= p1.x;
      y= p1.y;
      while (y< p2.y)
        { y+= Y_SPEED;
          if (y > p2.y)
            y=p2.y;
          window.paint(window.getGraphics());
          try { Thread.sleep(DELAY); } catch (Exception e) { }
        }
      pioli[i][j] = libero;
      libero = 0;
      window.paint(window.getGraphics());
    }
}

import fiji.io.*;

/**
 * Risolve il problema della torre di Hanoi
 * 
 * @author  
 * @version (a version number or a date)
 */
public class TorreDiHanoi
{

  public static void main(String args[])
    { SimpleReader in=new SimpleReader();

      System.out.print("Inserisci il numero di dischi: ");
      int n=in.readInt();

      hanoi(n, 'A', 'C');
    }

  static char terzoPiolo(char p1, char p2)
    { if (p1 != 'A' && p2!='A')
        return 'A';
      else if (p1!='B' && p2!='B')
        return 'B';
      else
        return 'C';
    }

  static void muovi(char da, char a)
    { System.out.println("Muovi un disco dal piolo "+da+" al piolo "+a);
    }

  static void hanoi(int n, char da, char a)
    { if (n<=1)
        muovi(da, a);
      else
        { char terzo=terzoPiolo(da, a);
          hanoi(n-1, da, terzo);
          muovi(da, a);
          hanoi(n-1, terzo, a);
        }
    }

}
